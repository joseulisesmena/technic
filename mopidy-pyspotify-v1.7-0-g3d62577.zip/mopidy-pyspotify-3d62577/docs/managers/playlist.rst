Playlist manager
****************
.. currentmodule:: spotify.manager

.. autoclass:: SpotifyPlaylistManager
    :members:
    :member-order: bysource
