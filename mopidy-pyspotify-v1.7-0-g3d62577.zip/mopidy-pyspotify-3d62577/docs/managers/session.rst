Session manager
***************

.. currentmodule:: spotify.manager

.. autoclass:: SpotifySessionManager
    :members:
    :exclude-members: loop
    :member-order: bysource
