Container manager
*****************
.. currentmodule:: spotify.manager

.. autoclass:: SpotifyContainerManager
    :members:
    :member-order: bysource
