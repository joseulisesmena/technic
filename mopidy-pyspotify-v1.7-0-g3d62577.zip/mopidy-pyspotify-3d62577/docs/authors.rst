*******
Authors
*******

Contributors to pyspotify in the order of appearance:

- Doug Winter <doug.winter@isotoma.com>
- Stein Magnus Jodal <stein.magnus@jodal.no>
- Thomas Jost <thomas.jost@gmail.com>
- Ben Firshman <ben@firshman.co.uk>
- Johannes Knutsen <johannes@knutseninfo.no>
- Antoine Pierlot-Garcin <antoine@bokbox.com>
- Jamie Kirkpatrick <jkp@kirkconsulting.co.uk>
- Francisco Jordano <arcturus@ardeenelinfierno.com>
- Andreas Franzén <andreas.franzen@osynlig.se>
- Benjamin Chapus <xben@free.fr>
- Tommaso Barbugli <tbarbugli@gmail.com>
- Bjørn Schjerve <bischjer@gmail.com>
- David Buchmann <david.buchmann@gmail.com>
